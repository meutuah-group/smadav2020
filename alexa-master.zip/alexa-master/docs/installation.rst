============
Installation
============

Install the package with pip::

    $ pip install read-the-docs-template
